package com.astontech;

import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    final static Logger logger = Logger.getLogger(Main.class);
    public static void main(String[] args) {
	// write your code here
    LessonDBConnection();
    }
    private static Connection LessonDBConnection(){
        String dbHost = "localhost";
        String dbName = "finalassessment";
        String dbUser = "consoleUser";
        String dbPass = "!@QW12qw";
        String useSSL = "true";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
        }catch(ClassNotFoundException ex){
            logger.error("com.astontech.dao.MySQL.MySQL.com.astontech.dao.MySQL.MySQL Driver not found");
            return null;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        logger.info("com.astontech.dao.MySQL.MySQL.com.astontech.dao.MySQL.MySQL driver registered.");
        Connection connection = null;
        try {
            /*
                        connection = DriverManager.getConnection("jdbc:mysql://"+dbHost+":3306/"+
                    dbName+"?autoReconnect=true&useSSL="+useSSL+"&noAccessToProcedureBodies="
                    + procBod,dbUser,dbPass);
             */
            connection = DriverManager.getConnection("jdbc:mysql://"+dbHost+":3306/"+
                    dbName+"?autoReconnect=true&useSSL=false",dbUser,dbPass);
        } catch (SQLException e) {
            System.out.println("Connection Failed!!!!!");
            e.printStackTrace();
            return null;
        }
        if(connection != null){
            logger.info("Success fully connected to MYSQL database");
            return connection;
        }else{
            logger.info("Connection failed!!!");
            return null;
        }
    }
}
